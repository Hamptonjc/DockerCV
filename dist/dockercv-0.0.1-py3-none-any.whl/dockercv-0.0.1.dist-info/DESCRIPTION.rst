DockerCV uses IPC mechanisms to allow for Numpy processing (OpenCV / PyTorch / TensorFlow / etc.) within a Docker container while still viewing the resulting images/videos locally on the host device. This eliminates the need for X11 Forwarding.


